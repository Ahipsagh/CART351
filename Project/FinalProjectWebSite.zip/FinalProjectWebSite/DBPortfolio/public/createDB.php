<?php

class MyDB extends SQLite3
   {
      function __construct()
      {
         $this->open('../db/AHportfolio.db');
         //open or create a db if it does not exist.
      }
   }

try
{
   $db = new MyDB();
   echo ("Opened or created Portfolio data base for Ariana Hipsagh successfully<br \>");
   $theQuery = 'CREATE TABLE artCollection (pieceID INTEGER PRIMARY KEY NOT NULL, artist TEXT, title TEXT,geoLoc TEXT, creationDate TEXT,descript ,image TEXT)';
    $ok = $db ->exec($theQuery);
   	// make sure the query executed
   	if (!$ok)
   	die($db->lastErrorMsg());
   	// if everything executed error less we will arrive at this statement
   	echo "Table Ahportfolio created successfully<br \>";
}
catch(Exception $e)
{
   die($e);
}
?>
