<!DOCTYPE html>
<html>
<head>
  <title>jQuery Portfolio</title>
  <script type="text/javascript" src="js/jquery-1.11.1.min.js"></script>
  <script type="text/javascript" src="js/script.js"></script>
  <script type="text/javascript" src="js/tags.js"></script>
  <script type="text/javascript" src ="js/jquery-ui.min.js"></script>
  <link rel="stylesheet" type="text/css" href="css/styles.css">
  <!-- <script type="text/javascript" src="https://hybrid.concordia.ca/a_hipsag/CART351/FinalProject/Portfolio/PhotoPortfolio-master/Portfolio/PhotoPortfolio-master/js/jquery-1.11.1.min.js"></script>
  <script type="text/javascript" src="https://hybrid.concordia.ca/a_hipsag/CART351/FinalProject/Portfolio/PhotoPortfolio-master/Portfolio/PhotoPortfolio-master/js/script.js"></script>
  <script type="text/javascript" src="https://hybrid.concordia.ca/a_hipsag/CART351/FinalProject/Portfolio/PhotoPortfolio-master/Portfolio/PhotoPortfolio-master/js/tags.js"></script>
  <script type="text/javascript" src ="https://hybrid.concordia.ca/a_hipsag/CART351/FinalProject/Portfolio/PhotoPortfolio-master/Portfolio/PhotoPortfolio-master/js/jquery-ui.min.js"></script>
  <link rel="stylesheet" type="text/css" href="https://hybrid.concordia.ca/a_hipsag//CART351/FinalProject/Portfolio/PhotoPortfolio-master/Portfolio/PhotoPortfolio-master/css/styles.css"> -->

</head>
<body>
<header>
  <div id="menu">
    <h2>Ariana Hipsagh</h2>
    <input id="search" style ="float:right;"type="text" placeholder ="search..."/>
  </div>
</header>
<div id="overlay"></div>
<div id="frame">
  <table id="frame-table">
    <tr>
      <td id = "left">
        <img src="img/AHleft.png" alt="left">
      </td>
      <td id = "right">
        <img src="img/AHright.png" alt="right">
      </td>
    </tr>
  </table>
  <a href = "#"><img id="main" src="" alt=""></a>
  <div id="description">
    <p></p>
  </div>
</div>
<section id="wrapper">
  <ul id="tags">
    <li class="active">All</li>
    <li>art</li>
    <li>design</li>
    <li>technology</li>
  </ul>
  <ul id="portfolio">
     <?php include_once("list.html") ?>
  </ul>
</section>
</body>
</html>
